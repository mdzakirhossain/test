<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>eDorpon</title>

    <!-- Bootstrap Core CSS -->
    <link href="asset/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Font Awesome CSS -->
    <link href="css/font-awesome.min.css" rel="stylesheet">
    
    
    <!-- Animate CSS -->
    <link href="css/animate.css" rel="stylesheet" >
    
    <!-- Owl-Carousel -->
    <link rel="stylesheet" href="css/owl.carousel.css" >
    <link rel="stylesheet" href="css/owl.theme.css" >
    <link rel="stylesheet" href="css/owl.transitions.css" >

    <!-- Custom CSS -->
    <link href="css/style.css" rel="stylesheet">
    <link href="css/responsive.css" rel="stylesheet">
    
    <!-- Colors CSS -->
    <link rel="stylesheet" type="text/css" href="css/color/green.css">
    
    
    
    <!-- Colors CSS -->
    <link rel="stylesheet" type="text/css" href="css/color/green.css" title="green">
    <link rel="stylesheet" type="text/css" href="css/color/light-red.css" title="light-red">
    <link rel="stylesheet" type="text/css" href="css/color/blue.css" title="blue">
    <link rel="stylesheet" type="text/css" href="css/color/light-blue.css" title="light-blue">
    <link rel="stylesheet" type="text/css" href="css/color/yellow.css" title="yellow">
    <link rel="stylesheet" type="text/css" href="css/color/light-green.css" title="light-green">

    <!-- Custom Fonts -->
    <link href='http://fonts.googleapis.com/css?family=Kaushan+Script' rel='stylesheet' type='text/css'>
    
    
    <!-- Modernizer js -->
    <script src="js/modernizr.custom.js"></script>

    
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body class="index">
    
    
    <!-- Styleswitcher
================================================== -->
        <div class="colors-switcher">
            <a id="show-panel" class="hide-panel"><i class="fa fa-tint"></i></a>        
                <ul class="colors-list">
                    <li><a title="Light Red" onClick="setActiveStyleSheet('light-red'); return false;" class="light-red"></a></li>
                    <li><a title="Blue" class="blue" onClick="setActiveStyleSheet('blue'); return false;"></a></li>
                    <li class="no-margin"><a title="Light Blue" onClick="setActiveStyleSheet('light-blue'); return false;" class="light-blue"></a></li>
                    <li><a title="Green" class="green" onClick="setActiveStyleSheet('green'); return false;"></a></li>
                    
                    <li class="no-margin"><a title="light-green" class="light-green" onClick="setActiveStyleSheet('light-green'); return false;"></a></li>
                    <li><a title="Yellow" class="yellow" onClick="setActiveStyleSheet('yellow'); return false;"></a></li>
                    
                </ul>

        </div>  
<!-- Styleswitcher End
================================================== -->

    <!-- Navigation -->
    <nav class="navbar navbar-default navbar-fixed-top">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header page-scroll">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand page-scroll" href="#page-top">eDorpon</a>
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav navbar-right">
                    <li class="hidden">
                        <a href="#page-top"></a>
                    </li>
                    <li>
                        <a class="page-scroll" href="index.php">Home</a>
                    </li>
                    <li>
                        <a class="page-scroll" href="service.php">Services</a>
                    </li>
                    <li>
                        <a class="page-scroll" href="portfolio.php">Portfolio</a>
                    </li>
                    <li>
                        <a class="page-scroll" href="about.php">About</a>
                    </li>
                    
                    <li>
                        <a class="page-scroll" href="team.php">Team</a>
                    </li>
                    <li>
                        <a class="page-scroll" href="https://edorpon.com/shop/">Shop</a>
                    </li>
                    <li>
                        <a class="page-scroll" href="latestnews.php">Latest News</a>
                    </li>
                    <li>
                        <a class="page-scroll" href="https://edorpon.com/shop/blog">Blog</a>
                    </li>
                    <li>
                        <a class="page-scroll" href="contactcareer.php">Career</a>
                    </li>
                    <li>
                        <a class="page-scroll" href="contact1.php">Contact</a>
                    </li>
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container-fluid -->
    </nav>

      <div class="top_section">
        <img src="images/logos/microlancer.jpg" style=" width: 100%; height: 514px; ">
        
        <h1 style="font-family: initial;color: #0d6510;margin-top: -85px;font-size: 29px;padding: 10px; margin-left: 61px;"></h1>
    </div>

    




<section id="feature" class="feature-section" style="padding-top: 77px;">
            <div class="container">
                <div class="row">
                    <div class="col-md-3 col-sm-6 col-xs-12">
                        <div class="feature">
                            <i class="fa fa-hospital-o"></i>
                            <div class="feature-content">
                                <h4 style="font-size: 17px;font-family: cursive;">Hospital Management</h4>
                                <p>eDorpon provides a best Hospital Management software & Dr. Chamber software.A hospital management system (HMS) is a computer or web based system that facilitates managing the functioning of the hospital or any medical set up.Cantact with eDorpon.</p>
                            </div>
                        </div>
                    </div><!-- /.col-md-3 -->
                    <div class="col-md-3 col-sm-6 col-xs-12">
                        <div class="feature">
                            <i class="fa fa-suitcase"></i>
                            <div class="feature-content">
                                <h4 style="font-size: 17px;font-family: cursive;">POS & INVENTORY </h4>
                                <p>A POS system is used to conduct sales at brick & mortar and eCommerce stores.edorpon follow some 
                                features to look for in a POS system-Sales monitoring and reporting,Billing and order processing, Inventory and stock management,Customer relationship, etc</p>
                            </div>
                        </div>
                    </div><!-- /.col-md-3 -->
                    <div class="col-md-3 col-sm-6 col-xs-12">
                        <div class="feature">
                            <i class="fa fa-calculator"></i>
                            <div class="feature-content">
                                <h4 style="font-size: 17px;font-family: cursive;">ACCOUNTING Management</h4>
                                <p>eDorpo provides Accounting software,that describes a type of application software that records and processes accounting transactions within functional modules such as accounts payable, accounts receivable, journal, general ledger, payroll, and trial balance.</p>
                            </div>
                        </div>
                    </div><!-- /.col-md-3 -->
                    <div class="col-md-3 col-sm-6 col-xs-12">
                        <div class="feature">
                            <i class="fa fa-bars"></i>
                            <div class="feature-content">
                                <h4 style="font-size: 17px;font-family: cursive;">HOTEL Management</h4>
                                <p>Our hotel management software is not just a Hotel system but an automated Hotel ERP solution that will improve your corporate marketing, guest management service, increase your work efficiency & employee productivity, Payroll & Account management and so on.</p>
                            </div>
                        </div>
                    </div>
                </div><!-- /.row -->
            
            </div><!-- /.container -->
        </section>




<div id="pricing" class="pricing-section">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="col-md-12">
                        <div class="section-title text-center">
                            <h3 style="
    color: #1da246;
    font-size: 29px;font-family: cursive;
">Business Management Software</h3>
                            <p class="white-text" style = "font-family: cursive;">Find the best Business Management Software for your business</p>
                        </div>
                    </div>
                </div>
            </div>
                    
            <div class="row">
                        
                <div class="pricing">
                        
                        <div class="col-md-12">
                            <div class="pricing-table">
                                <div class="plan-name">
                                    <h3 >Software Development Costs</h3>
                                </div> <h5>‘How much will the Software cost?’</h5>
                               <!-- <div class="plan-price">
                                    <div class="price-value">$49<span>.00</span></div>
                                    <div class="interval">per month</div>
                                </div>--->
                                <div class="plan-list">
                                    <ul>
                                        <li>To simply say that the cost depends on the features of the Software.</li>
                                        <li>The costs depend on the features you want in the software.</li>
                                        <li>An offline software, like that of a POS SYSTEM</li>
                                        <li>Will cost you fewer bucks, but an app that integrates</li>
                                        
                                    </ul>
                                </div>
                                <div class="plan-signup">
                                    <a href="contact1.php" class="btn-system btn-small" >Contact us</a>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-md-12">
                            <div class="pricing-table">
                                <div class="plan-name">
                                    <h3 >Software development costs depend on</h3>
                                </div>
                                
                                <div class="plan-list">
                                    <ul >
                                        <li>Type of SOFTWARE-INVENTORY,POS,ACCOUNTING</li>
                                        <li>Platform – PHP, ASP.net etc</li>
                                        <li>Number of Pages</li>
                                        <li>Features</li>
                                        <li>Infrastructure </li>
                                        <li>Design – Basic, Individual, or Custom</li>
                                    </ul>
                                </div>
                                <div class="plan-signup">
                                    <a href="contact1.php" class="btn-system btn-small" >Contact us</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="pricing-table">
                                <div class="plan-name">
                                    <h3 >Custom Design</h3>
                                </div>
                                
                                <div class="plan-list">
                                    <ul s>
                                        <li>We craft smart solutions with research-backed strategies and high-quality</li>
                                        <li>Professional-grade custom product designs</li>
                                        <li>We're fanatical about the UX/UI design process</li>
                                        <li>we go deep to cover all user scenarios and edge cases.</li>
                                        <li>We get noticed for our brand design</li>
                                    </ul>
                                </div>
                                <div class="plan-signup">
                                    <a href="contact1.php" class="btn-system btn-small">Contact us</a>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-md-12">
                            <div class="pricing-table">
                                <div class="plan-name">
                                    <h3 >Scalable Applications</h3>
                                </div>
                                
                                <div class="plan-list">
                                    <ul >
                                        <li>We architect and code hard-core iOS and Android mobile apps</li>
                                        <li>Built for scale and security.</li>
                                        <li>We don't shy away from building custom web platforms either</li>
                                        <li> Our product engineering folks are</li>
                                        <li>Industry veterans from leading technology organizations.We build best-in-class mobile experiences for Android</li>
                                        
                                    </ul>
                                </div>
                                <div class="plan-signup">
                                    <a href="contact1.php" class="btn-system btn-small">Contact us</a>
                                </div>
                            </div>
                        </div>
                    
                        <div class="col-md-12">
                            <div class="pricing-table">
                                <div class="plan-name">
                                    <h3>Launch & Growth</h3>
                                </div>
                                
                                <div class="plan-list">
                                    <ul >
                                        <li>Development isn’t just about writing code</li>
                                        <li>We know how to get you to the starting line on time and within budget,But we don’t stop there</li>
                                        <li>We’re strong believers in executing ongoing,fluid agile product releases</li>
                                        <li>Using informed decisions based on measured learnings from real users</li>
                                        <li>Launching is just the beginning</li>
                                    </ul>
                                </div>
                                <div class="plan-signup">
                                    <a href="contact1.php" class="btn-system btn-small">Contact us</a>
                                </div>
                            </div>
                        </div>
                        
                      <div class="col-md-12">
                            <div class="pricing-table">
                                <div class="plan-name">
                                    <h3 >While a complex app requires the services of:</h3>
                                </div>
                               
                                <div class="plan-list">
                                    <ul >
                                        <li>Project Manager</li>
                                        <li>Backend Developer</li>
                                        <li>Software Developers</li>
                                        <li>UI/UX Designers</li>
                                        <li>System Administrator </li>
                                        <li>QA Engineer</br> Developer</li>
                                    </ul>
                                </div>
                                <div class="plan-signup">
                                    <a href="contact1.php" class="btn-system btn-small" >Contact us</a>
                                </div>
                            </div>
                        </div>
                        
                    </div>
                        
                        
            </div>
        </div>
    </div>
    



     <footer class="style-1">
            <div class="container">
                <div class="row">
                    <div class="col-md-4 col-xs-12">
                        <span class="copyright">2020 &copy; <a >ALL Rights Reserved by eDorpon</a></span>
                    </div>
                    <div class="col-md-4 col-xs-12" style="margin-left: -11px;">
                        <div class="footer-link">
                            <ul class="pull-right" style="margin-top: 1px;">
                                <li><a href="#">Privacy Policy</a><a href="#">    Terms of Use</a>
                                </li>
                                <!--<li><a href="#">Terms of Use</a>
                                </li>--->
                            </ul>
                        </div>
                    </div>
                    <div class="col-md-4 col-xs-12">
                        <div class="footer-social text-center">
                            <ul>
                                <li><a href="https://twitter.com/edorpon"><i class="fa fa-twitter"></i></a></li>
                                <li><a href="https://www.facebook.com/edorponbd/"><i class="fa fa-facebook"></i></a></li>
                                <li><a href="https://www.linkedin.com/company/edorponofficial/"><i class="fa fa-linkedin"></i></a></li>
                                <li><a href="www.edorpon.com"><i class="fa fa-dribbble"></i></a></li>
                                
                            </ul>
                        </div>
                    </div>
                    
                </div>
            </div>
        </footer>
    




    <div id="loader">
        <div class="spinner">
            <div class="dot1"></div>
            <div class="dot2"></div>
        </div>
    </div>

    

    <!-- jQuery Version 2.1.1 -->
    <script src="js/jquery-2.1.1.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="asset/js/bootstrap.min.js"></script>

    <!-- Plugin JavaScript -->
    <script src="js/jquery.easing.1.3.js"></script>
    <script src="js/classie.js"></script>
    <script src="js/count-to.js"></script>
    <script src="js/jquery.appear.js"></script>
    <script src="js/cbpAnimatedHeader.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/jquery.fitvids.js"></script>
    <script src="js/styleswitcher.js"></script>

    <!-- Contact Form JavaScript -->
    <script src="js/jqBootstrapValidation.js"></script>
    <script src="js/contact_me.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="js/script.js"></script>

</body>

</html>

