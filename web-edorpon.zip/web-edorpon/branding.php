<?php include ("header.php"); ?>

<body class="index">
    
    
    <!-- Styleswitcher
================================================== -->
        <div class="colors-switcher">
            <a id="show-panel" class="hide-panel"><i class="fa fa-tint"></i></a>        
                <ul class="colors-list">
                    <li><a title="Light Red" onClick="setActiveStyleSheet('light-red'); return false;" class="light-red"></a></li>
                    <li><a title="Blue" class="blue" onClick="setActiveStyleSheet('blue'); return false;"></a></li>
                    <li class="no-margin"><a title="Light Blue" onClick="setActiveStyleSheet('light-blue'); return false;" class="light-blue"></a></li>
                    <li><a title="Green" class="green" onClick="setActiveStyleSheet('green'); return false;"></a></li>
                    
                    <li class="no-margin"><a title="light-green" class="light-green" onClick="setActiveStyleSheet('light-green'); return false;"></a></li>
                    <li><a title="Yellow" class="yellow" onClick="setActiveStyleSheet('yellow'); return false;"></a></li>
                    
                </ul>

        </div>  
<!-- Styleswitcher End
================================================== -->

  <nav class="navbar navbar-default navbar-fixed-top" style="background: black;">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header page-scroll">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand page-scroll" href="#page-top"style="font-family: cursive;">eDorpon</a>
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav navbar-right">
                    <li class="hidden">
                        <a href="#page-top"></a>
                    </li>
                    <li>
                        <a class="page-scroll" href="index.php"style="font-family: cursive;">Home</a>
                    </li>
                    <li>
                        <a class="page-scroll" href="service.php"style="font-family: cursive;">Services</a>
                    </li>
                    <li>
                        <a class="page-scroll" href="portfolio.php"style="font-family: cursive;">Portfolio</a>
                    </li>
                    <li>
                        <a class="page-scroll" href="about.php"style="font-family: cursive;">About</a>
                    </li>
                    
                    <li>
                        <a class="page-scroll" href="team.php"style="font-family: cursive;">Team</a>
                    </li>
                    <li>
                        <a class="page-scroll" href="https://edorpon.com/shop/"style="font-family: cursive;">Shop</a>
                    </li>
                    <li>
                        <a class="page-scroll" href="latestnews.php"style="font-family: cursive;">Latest News</a>
                    </li>
                   <!-- <li>
                        <a class="page-scroll" href="product.php"style="font-family: cursive;">Product</a>
                    </li>-->
                    <li>
                        <a class="page-scroll" href="https://edorpon.com/shop/blog"style="font-family: cursive;">Blog</a>
                    </li>
                    <li>
                        <a class="page-scroll" href="contactcareer.php"style="font-family: cursive;">Careers</a>
                    </li>
                    <li>
                        <a class="page-scroll" href="contact1.php"style="font-family: cursive;">Contact</a>
                    </li>
                    
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container-fluid -->
    </nav>

   
 <div class="top_section">
        <img src="images/logos/themeforest.jpg" style=" width: 100%; height: 465px; ">
        
        <h1 style="font-family: initial;color: #fff;margin-top: -85px;font-size: 29px;padding: 10px; margin-left: 61px;"></h1>
    </div>
      



 <section id="feature" class="feature-section" style=" padding-top: 77px;">
            <div class="container">
                <div class="row">
                    <div class="col-md-3 col-sm-6 col-xs-12">
                        <div class="feature">
                            <i class="fa fa-bar-chart"></i>
                            <div class="feature-content">
                                <h4 style="font-size: 20px;font-family: serif;">Trusted e-Commerce Developer</h4>
                                <p style="font-size: 16px;font-family: serif;">eDorpon software company works Multi-vendor Marketplace Websites are one of the top trending business models. We have an excellent team of experts</p>
                                <a class="animated3 slider btn btn-primary btn-min-block" href="#">Live Demo</a>
                            </div>
                        </div>
                    </div><!-- /.col-md-3 -->
                    <div class="col-md-3 col-sm-6 col-xs-12">
                        <div class="feature">
                            <i class="fa fa-bars"></i>
                            <div class="feature-content">
                                <h4 style="font-size: 20px;font-family: serif;">POS with eCommerce</h4>
                                <p style="font-size: 16px;font-family: serif;" >POS with eCommerce helps to manage online order systematically. No more extra work, just click, create invoice & ship product to the customer's address.</p>
                                <a class="animated3 slider btn btn-primary btn-min-block" href="#">Live Demo</a>
                            </div>
                        </div>
                    </div><!-- /.col-md-3 -->
                    <div class="col-md-3 col-sm-6 col-xs-12">
                        <div class="feature">
                            <i class="fa fa-archive"></i>
                            <div class="feature-content">
                                <h4 style="font-size: 20px;font-family: serif;">eCommerce </h4>
                                <p style="font-size: 16px;font-family: serif;">A professional eCommerce website requires creativity, innovation, and user-friendliness. Apart from this, an eCommerce store has to be responsive </p>
                                <a class="animated3 slider btn btn-primary btn-min-block" href="#">Live Demo</a>
                            </div>
                        </div>
                    </div><!-- /.col-md-3 -->
                    <div class="col-md-3 col-sm-6 col-xs-12">
                        <div class="feature">
                            <i class="fa fa-adjust"></i>
                            <div class="feature-content">
                                <h4 style="font-size: 20px;font-family: serif;">Branding</h4>
                                <p style="font-size: 16px;font-family: serif;">eDorpon A professional work Branding.If you are looking for the best Branding Company at an affordable budget then contact us. </p>
                                <a class="animated3 slider btn btn-primary btn-min-block" href="#">Live Demo</a>
                            </div>
                        </div>
                    </div>
                </div><!-- /.row -->
            
            </div><!-- /.container -->
        </section>




<div id="pricing" class="pricing-section">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="col-md-12">
                        <div class="section-title text-center">
                            <h3 style="
    color: #1da246;
    font-size: 29px;font-family: cursive;
">eCommerce software solution for eCommerce business management.</h3>
<p class="white-text" style="font-family: cursive;font-size: 18px;">The best eCommerce development company with client are helping for e-commerce design and development services for your needs.</p>
                            
                        </div>
                    </div>
                </div>
            </div>
                    
            <div class="row">
                        
                <div class="pricing">
                        
                        <div class="col-md-12">
                            <div class="pricing-table">
                                <div class="plan-name">
                                    <h3 style="font-family: cursive;" >eCommerce IT solutions</h3>
                                </div> <h5 style="font-family: cursive;font-size: 18px;" >We help you optimize your online site for high performance, increased traffic, and enhance profitability.</h5>
                           
                                <div class="plan-list">
                                    <ul>
                                        <li   style="font-family: cursive;font-size: 18px;">Focused on providing scalable solutions and ecommerce enterprise portals services, we can create ecommerce website from scratch or optimize existing website.</li>
                                        
                                                                               
                                    <li  style="font-family: cursive;font-size: 18px;">We provide end to end ecommerce website solutions to all kinds of small, medium and large businesses. Our ecommerce stores are optimized for desktop, mobile, and tablets.</li>
                                        
                                    </ul>
                                </div>
                                
                            </div>
                        </div>
                        
                        <div class="col-md-12">
                            <div class="pricing-table">
                                <div class="plan-name">
                                    <h3 style="font-family: cursive;">B2B eCommerce Solutions</h3>
                                </div>
                                
                                <div class="plan-list">
                                    <ul>
                                        <li  style="font-family: cursive;font-size: 18px;" >Cutting-edge B2B eCommerce & B2C solutions to develop an integrated.</li>
                                        <li style="font-family: cursive;font-size: 18px;" >Feature-rich ecommerce site for omnichannel experience.</li>
                                        <li style="font-family: cursive;font-size: 18px;" >Secure and high-performance shopping cart development services for a seamless shopping experience to customers across devices.</br>We help small businesses to achieve their goals and objective by providing all kinds of small solutions like website for web presence, Accounting management software and so on.</li>
                                        
                                    </ul>
                                </div>
                                
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="pricing-table">
                                <div class="plan-name">
                                    <h3 style="font-family: cursive;">Web Portal Development</h3>
                                </div>
                                
                                <div class="plan-list">
                                    <ul>
                                        <li style="font-family: cursive;font-size: 18px;" >Our web portal development services enhance productivity of business.We craft smart solutions with research-backed strategies and high-quality</li>
                                        <li style="font-family: cursive;font-size: 18px;" >We design intuitive user interfaces with quick page load.Professional-grade custom product designs</li>
                                        <li style="font-family: cursive;font-size: 18px;" >We're fanatical about the UX/UI design process</li>
                                        <li style="font-family: cursive;font-size: 18px;" >we go deep to cover all user scenarios and edge cases.</li>
                                        <li style="font-family: cursive;font-size: 18px;" >We get noticed for our brand design</li>
                                    </ul>
                                </div>
                                
                            </div>
                        </div>
                        
                        <div class="col-md-12">
                            <div class="pricing-table">
                                <div class="plan-name">
                                    <h3 style="font-family: cursive;">Omnichannel User Experience</h3>
                                </div>
                                
                                <div class="plan-list">
                                    <ul>
                                        <li style="font-family: cursive;font-size: 18px;" >Connected mobile and Internet enabled devices proliferate to transform the customer experience across platforms such as smart watch, TV, m-Commerce and e-Commerce applications.</li>
                                        <li style="font-family: cursive;font-size: 18px;" >Built for scale and security.</li>
                                        <li style="font-family: cursive;font-size: 18px;">We don't shy away from building custom web platforms either</li>
                                        
                                         <li style="font-family: cursive;font-size: 18px;" > A start-up entrepreneur needs an efficient solution at an affordable budget. We provide the best quality software at affordable budget.</li>
                                        
                                    </ul>
                                </div>
                               
                            </div>
                        </div>
                    
                        <div class="col-md-12">
                            <div class="pricing-table">
                                <div class="plan-name">
                                    <h3 style="font-family: cursive;">Customer Loyalty</h3>
                                </div>
                                
                                <div class="plan-list">
                                    <ul>
                                        <li style="font-family: cursive;font-size: 18px;">Customer Loyalty and coupons solutions to lead a shift away from transaction based systems to establishing deep connection with customer on a continuous basis</li>
                                        <li style="font-family: cursive;font-size: 18px;">We know how to get you to the starting line on time and within budget,But we don’t stop there</li>
                                        <li style="font-family: cursive;font-size: 18px;">We’re strong believers in executing ongoing,fluid agile product releases</li>
                                        <li style="font-family: cursive;font-size: 18px;">Using informed decisions based on measured learnings from real users</li>
                                       
                                    </ul>
                                </div>
                                
                            </div>
                        </div>
                        
                      <div class="col-md-12">
                            <div class="pricing-table">
                                <div class="plan-name">
                                    <h3 style="font-family: cursive;">Launch & Growth</h3>
                                </div>
                               
                                <div class="plan-list">
                                    <ul>
                                        <li style="font-family: cursive;font-size: 18px;">Development isn’t just about writing code</li>
                                        <li style="font-family: cursive;font-size: 18px;">We know how to get you to the starting line on time and within budget,But we don’t stop there</li>
                                        <li style="font-family: cursive;font-size: 18px;">We’re strong believers in executing ongoing,fluid agile product releases</li>
                                        <li style="font-family: cursive;font-size: 18px;">Using informed decisions based on measured learnings from real users</li>
                                        <li style="font-family: cursive;font-size: 18px;">Launching is just the beginning</li>
                                        <li  style="font-family: cursive;font-size: 18px;"> We partner with retailers, manufacturers </li>

                                    </ul>
                                </div>
                               
                            </div>
                        </div>
                        
                    </div>
                        
                        
            </div>
        </div>
    </div>
    
    <section id="contact1" class="contact">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="section-title text-center">
                        <h3 >Contact With Us</h3>
                        <p  >Meet our experts best solution for you </p>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <form name="sentMessage" id="contactForm" novalidate>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <input type="text" class="form-control" placeholder="Your Name *" id="name" required data-validation-required-message="Please enter your name.">
                                    <p class="help-block text-danger"></p>
                                </div>
                                <div class="form-group">
                                    <input type="email" class="form-control" placeholder="Your Email *" id="email" required data-validation-required-message="Please enter your email address.">
                                    <p class="help-block text-danger"></p>
                                </div>
                                <div class="form-group">
                                    <input type="tel" class="form-control" placeholder="Your Phone *" id="phone" required data-validation-required-message="Please enter your phone number.">
                                    <p class="help-block text-danger"></p>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <textarea class="form-control" placeholder="Your Message *" id="message" required data-validation-required-message="Please enter a message."></textarea>
                                    <p class="help-block text-danger"></p>
                                </div>
                            </div>
                            <div class="clearfix"></div>
                            <div class="col-lg-12 text-center">
                                <div id="success"></div>
                                <button type="submit" class="btn btn-primary">Send Message</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            <div class="row">
                <div class="col-md-4">
                    <div class="footer-contact-info">
                        <h4 >Contact info</h4>
                        <ul>
                            <li><strong>E-mail :</strong> info@edorpon.com</li>
                            <li><strong>Hot-line :</strong> +8801888015000</li>
                            
                            <li><strong>Web :</strong> www.edorpon.com</li>
                        </ul>
                    </div>
                </div>
                <div class="col-md-4 col-md-offset-4">
                    <div class="footer-contact-info">
                        <h4 >Working Hours</h4>
                        <ul>
                            <li><strong>Sunday-Wed :</strong> 10 am to 6 pm</li>
                            
                            <li><strong>Sat :</strong> 10 am to 6 pm</li>
                            <li><strong>Thurs-Fri :</strong> Closed</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
         <footer class="style-1">
            <div class="container">
                <div class="row">
                    <div class="col-md-4 col-xs-12">
                        <span class="copyright">2020 &copy; <a >ALL Rights Reserved by eDorpon</a></span>
                    </div>
                    <div class="col-md-4 col-xs-12" style="margin-left: -11px;">
                        <div class="footer-link">
                            <ul class="pull-right" style="margin-top: 1px;">
                                <li><a href="#">Privacy Policy</a><a href="#">    Terms of Use</a>
                                </li>
                                <!--<li><a href="#">Terms of Use</a>
                                </li>--->
                            </ul>
                        </div>
                    </div>
                    <div class="col-md-4 col-xs-12">
                        <div class="footer-social text-center">
                            <ul>
                                <li><a href="https://twitter.com/edorpon"><i class="fa fa-twitter"></i></a></li>
                                <li><a href="https://www.facebook.com/edorponbd/"><i class="fa fa-facebook"></i></a></li>
                                <li><a href="https://www.linkedin.com/company/edorponofficial/"><i class="fa fa-linkedin"></i></a></li>
                                <li><a href="www.edorpon.com"><i class="fa fa-dribbble"></i></a></li>
                                
                            </ul>
                        </div>
                    </div>
                    
                </div>
            </div>
        </footer>
    </section>
    
   <div id="loader">
        <div class="spinner">
            <div class="dot1"></div>
            <div class="dot2"></div>
        </div>
    </div>

    

    <!-- jQuery Version 2.1.1 -->
    <script src="js/jquery-2.1.1.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="asset/js/bootstrap.min.js"></script>

    <!-- Plugin JavaScript -->
    <script src="js/jquery.easing.1.3.js"></script>
    <script src="js/classie.js"></script>
    <script src="js/count-to.js"></script>
    <script src="js/jquery.appear.js"></script>
    <script src="js/cbpAnimatedHeader.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/jquery.fitvids.js"></script>
    <script src="js/styleswitcher.js"></script>

    <!-- Contact Form JavaScript -->
    <script src="js/jqBootstrapValidation.js"></script>
    <script src="js/contact_me.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="js/script.js"></script>

</body>

</html>