 <nav class="navbar navbar-default navbar-fixed-top">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header page-scroll">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand page-scroll" href="#page-top">eDorpon</a>
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav navbar-right">
                    <li class="hidden">
                        <a href="#page-top"></a>
                    </li>
                    <li>
                        <a class="page-scroll" href="index.php">Home</a>
                    </li>
                    <li>
                        <a class="page-scroll" href="service.php">Services</a>
                    </li>
                    <li>
                    <li>
                        <a class="page-scroll" href="portfolio.php">Portfolio</a>
                    </li>
                    <li>
                        <a class="page-scroll" href="about.php">About</a>
                    </li>
                    
                    <li>
                        <a class="page-scroll" href="team.php">Team</a>
                    </li>
                    <li>
                        <a class="page-scroll" href="https://edorpon.com/shop/">Shop</a>
                    </li>
                    <li>
                        <a class="page-scroll" href="latestnews.php">Latest News</a>
                    </li>
                    <li>
                        <a class="page-scroll" href="https://edorpon.com/shop/blog">Blog</a>
                    </li>
                    <li>
                        <a class="page-scroll" href="contactcareer.php">Career</a>
                    </li>
                    <li>
                        <a class="page-scroll" href="contact1.php">Contact</a>
                    </li>
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container-fluid -->
    </nav>
    