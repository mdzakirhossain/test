<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>eDorpon</title>

    <!-- Bootstrap Core CSS -->
    <link href="asset/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Font Awesome CSS -->
    <link href="css/font-awesome.min.css" rel="stylesheet">
    
    
    <!-- Animate CSS -->
    <link href="css/animate.css" rel="stylesheet" >
    
    <!-- Owl-Carousel -->
    <link rel="stylesheet" href="css/owl.carousel.css" >
    <link rel="stylesheet" href="css/owl.theme.css" >
    <link rel="stylesheet" href="css/owl.transitions.css" >

    <!-- Custom CSS -->
    <link href="css/style.css" rel="stylesheet">
    <link href="css/responsive.css" rel="stylesheet">
    
    <!-- Colors CSS -->
    <link rel="stylesheet" type="text/css" href="css/color/green.css">
    
    
    
    <!-- Colors CSS -->
    <link rel="stylesheet" type="text/css" href="css/color/green.css" title="green">
    <link rel="stylesheet" type="text/css" href="css/color/light-red.css" title="light-red">
    <link rel="stylesheet" type="text/css" href="css/color/blue.css" title="blue">
    <link rel="stylesheet" type="text/css" href="css/color/light-blue.css" title="light-blue">
    <link rel="stylesheet" type="text/css" href="css/color/yellow.css" title="yellow">
    <link rel="stylesheet" type="text/css" href="css/color/light-green.css" title="light-green">

    <!-- Custom Fonts -->
    <link href='http://fonts.googleapis.com/css?family=Kaushan+Script' rel='stylesheet' type='text/css'>
    
    
    <!-- Modernizer js -->
    <script src="js/modernizr.custom.js"></script>

    
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    <style>
        a:active {
  background-color: yellow;
}</style>

</head>

<body class="index">
    
    
    <!-- Styleswitcher
================================================== -->
        <div class="colors-switcher">
            <a id="show-panel" class="hide-panel"><i class="fa fa-tint"></i></a>        
                <ul class="colors-list">
                    <li><a title="Light Red" onClick="setActiveStyleSheet('light-red'); return false;" class="light-red"></a></li>
                    <li><a title="Blue" class="blue" onClick="setActiveStyleSheet('blue'); return false;"></a></li>
                    <li class="no-margin"><a title="Light Blue" onClick="setActiveStyleSheet('light-blue'); return false;" class="light-blue"></a></li>
                    <li><a title="Green" class="green" onClick="setActiveStyleSheet('green'); return false;"></a></li>
                    
                    <li class="no-margin"><a title="light-green" class="light-green" onClick="setActiveStyleSheet('light-green'); return false;"></a></li>
                    <li><a title="Yellow" class="yellow" onClick="setActiveStyleSheet('yellow'); return false;"></a></li>
                    
                </ul>

        </div>  
<!-- Styleswitcher End
================================================== -->

    <!-- Navigation -->
    <nav class="navbar navbar-default navbar-fixed-top">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header page-scroll">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand page-scroll" href="#page-top">eDorpon</a>
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav navbar-right">
                    <li class="hidden">
                        <a href="#page-top"></a>
                    </li>
                    <li>
                        <a class="page-scroll" href="index.php">Home</a>
                    </li>
                      <li>
                        <a class="page-scroll" href="service.php">Services</a>

                    </li>
                    <li>
                        <a class="page-scroll" href="portfolio.php">Portfolio</a>
                    </li>
                    <li>
                        <a class="page-scroll" href="about.php"   >About</a>
                    </li>
                  
                    <li>
                        <a class="page-scroll" href="team.php">Team</a>
                    </li>
                    <li>
                        <a class="page-scroll" href="https://edorpon.com/shop/">Shop</a>
                    </li>
                    <li>
                        <a class="page-scroll" href="latestnews.php">Latest News</a>
                    </li>
                    <li>
                        <a class="page-scroll" href="https://edorpon.com/shop/blog">Blog</a>
                    </li>
                    <li>
                        <a class="page-scroll" href="contactcareer.php">Career</a>
                    </li>
                    <li>
                        <a class="page-scroll" href="contact1.php">Contact</a>
                    </li>
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container-fluid -->
    </nav>

    <div class="top_section">
        <img src="images/portfolio/img3.jpg" style=" width: 100%; height: 504px; ">
        
        <h1 style="font-family: initial;color: #fff;margin-top: -85px;font-size: 29px;padding: 10px; margin-left: 61px;"></h1>
    </div>
    

      <section >
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h2 style="text-align: justify;line-height: 19px;color: #060101;font-family: auto;padding-top: 56px;margin-bottom: -99px;font-size: 18px;"> "eDorpon is an international standard Software Company in Bangladesh since 2018.We have an excellent team of experts who are highly skilled in software architects, software engineers, determined solid growth in the web solution market.eDorpon is an international standard Software Company in Bangladesh. We Work with National & International Clients & Partners.We aim to provide interactive and cost-effective solutions by establishing a bridge between the latest Smart Technologies"</br></h2>
                    <!--<button type="submit" class="btn btn-primary">Buy This Template</button>--->
                </div>
            </div>
     
     </section>
    
    <!-- Start About Us Section -->
    <section id="about-us" class="about-us-section-1" style="
    padding-top: 1px;">
        <div class="container">
            <div class="row">
                <div class="col-md-12 col-sm-12">
                    <div class="section-title text-center">
                            <h3 style="color: #861c1c;font-family: initial;padding-top: 89px;"></br><b></b></h3>
                          <!--  <p style="color: #01161d;font-family: initial;font-size: 16px;"><b>"eDorpon is an international standard Software Company in Bangladesh since 2018.We have an excellent team of experts who are highly skilled in software architects, software engineers, determined solid growth in the web solution market. eDorpon is an international standard Software Company in Bangladesh.We Work with National & International Clients & Partners.We aim to provide interactive and cost-effective solutions by establishing a bridge between the latest Smart Technologies"</b></p>-->
                        </div>
                </div>
            </div>
            <div class="row">
                
                <div class="col-md-4">
                    <div class="welcome-section text-center">
                        <img src="images/about-01.jpg" class="img-responsive" alt="..">
                        <h4 style="color: #060101;font-family: auto;font-size: 16px;padding-top: 0px;"><b>Office Philosophy</b></h4>
                        <div class="border"></div>
                        <p style="font-size: 16px;color: #060101;font-family: auto;font-style: oblique;padding-top: 1px;"><b>We service our all clients with the same care & understanding.Fortune 100 companies to start-up firms have taken advantage of our flexible work force strategy.We focused on versatile project management intending to provide Software, Web, ERP & other solutions with global acceptability.</br></b></p>
                    </div>
                </div>
                
                <div class="col-md-4">
                    <div class="welcome-section text-center">
                        <img src="images/header-back.png" class="img-responsive" alt="..">
                        <h4 style="font-size: 16px;color: #060101;font-family: auto;padding-top: 0px;"><b>Office Mission & Vission</b></h4>
                        <div class="border"></div>
                         <p style="font-size: 16px;font-style: oblique;color: #060101;font-family: auto;padding-top: 1px;"><b>eDorpon software company, Our mission is to bring the World community state of the art solutions to information systems technology challenges which are reliable and  economical and Our mission  100% client satisfaction by delivering creative and reliable solutions according to our client's needs.</b></p>
                    </div>
                </div>
                
                <div class="col-md-4">
                    <div class="welcome-section text-center">
                        <img src="images/about-03.jpg" class="img-responsive" alt="..">
                        <h4 style="color: #060101;font-family: auto;font-size: 16px;padding-top: 0px;"><b>Office Value & Rules</b></h4>
                        <div class="border"></div>
                        <p style="font-size: 16px;font-style: oblique;color: #060101;font-family: auto;padding-top: 1px;"><b>Our stores have some unique features like unlimited products and categories, secure one-page checkout, subscription system and so on. We use a highly secured Laravel platform.We use a highly secured Laravel platform &solved the most complex problem in a more simpler way.</b></p>
                    </div>
                </div>
                
            </div><!-- /.row -->            
            
        </div><!-- /.container -->
    </section>
    <!-- End About Us Section -->


    <!-- Start About Us Section 2 -->
    <div class="about-us-section-2">
        <div class="container">
            <div class="row">
                
                <div class="col-md-6">
                    <div class="skill-shortcode">
                        
                        <!-- Progress Bar -->
                        <div class="skill">
                            <p style="color: #000;font-family: initial;font-size: 15px;"><b>Mobile Apps</b></p>          
                            <div class="progress">         
                                <div class="progress-bar" role="progressbar"  data-percentage="60">
                                    <span class="progress-bar-span" >60%</span>
                                    <span class="sr-only">60% Complete</span>
                                </div>
                            </div>  
                        </div>
                        
                        <!-- Progress Bar -->
                        <div class="skill">
                            <p style="color: #000;font-family: initial;font-size: 15px;"><b>Web Design</b></p>          
                            <div class="progress">         
                                <div class="progress-bar" role="progressbar"  data-percentage="95">
                                    <span class="progress-bar-span" >95%</span>
                                    <span class="sr-only">95% Complete</span>
                                </div>
                            </div>  
                        </div>
                        
                        <!-- Progress Bar -->
                        <div class="skill">
                            <p style="color: #000;font-family: initial;font-size: 15px;"><b>Software Development</b></p>          
                            <div class="progress">         
                                <div class="progress-bar" role="progressbar"  data-percentage="80">
                                    <span class="progress-bar-span" >80%</span>
                                    <span class="sr-only">80% Complete</span>
                                </div>
                            </div>  
                        </div>
                        
                        <!-- Progress Bar -->
                        <div class="skill">
                            <p style="color: #000;font-family: initial;font-size: 15px;"><b>ERP</b></p>          
                            <div class="progress">         
                                <div class="progress-bar" role="progressbar"  data-percentage="100">
                                    <span class="progress-bar-span" >100%</span>
                                    <span class="sr-only">100% Complete</span>
                                </div>
                            </div>  
                        </div>
                        
                        <!-- Progress Bar -->
                        <div class="skill">
                            <p style="color: #000;font-family: initial;font-size: 15px;"><b>Travel & Tour & Ait Ticket & Visa Processing</b></p>          
                            <div class="progress">         
                                <div class="progress-bar" role="progressbar"  data-percentage="70">
                                    <span class="progress-bar-span" >70%</span>
                                    <span class="sr-only">70% Complete</span>
                                </div>
                            </div>  
                        </div>
                                                            
                    </div>
                </div>
                
                <div class="col-md-6">
                    <div id="carousel-example-generic" class="carousel slide about-slide" data-ride="carousel">
                        <!-- Indicators -->
                        <ol class="carousel-indicators">
                            <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
                            <li data-target="#carousel-example-generic" data-slide-to="1"></li>
                            <li data-target="#carousel-example-generic" data-slide-to="2"></li>
                        </ol>

                        <!-- Wrapper for slides -->
                        <div class="carousel-inner">
                            <div class="item active">
                                <img src="images/about-01.jpg" alt="">
                            </div>
                            <div class="item">
                                <img src="images/about-02.jpg" alt="">
                            </div>
                            <div class="item">
                                <img src="images/about-03.jpg" alt="">
                            </div>
    
                        </div>
  
                    </div>
                </div>
                
            </div>
        </div>
    </div>
    <!-- Start About Us Section 2 -->


    


    <!-- Start Feature Section -->
        <section id="service" class="services-section" style="padding-top: 0px;">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="section-title text-center">
                            <h3 style="color: #861c1c;font-family: initial;padding-top: 32px;font-size: 22px;margin-bottom: 5px;"><b>eDorpon is the best for your Business solution</b></h3>
                            <p style="color: #311212;font-size: 17px;font-family: initial;"><b></b></p>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-4 col-sm-6 col-xs-12">
                        <div class="feature-2">
                            <div class="media">
                                <div class="pull-left">
                                    <i class="fa fa-reddit-square"></i>
                                    <div class="border"></div>
                                </div>
                                <div class="media-body">
                                    <h4 class="media-heading" style="color: #094848;font-size: 18px;font-family: initial;line-height: 0px;"><b>Reasons why clients choose us</b></h4>
                                    <p style="color: #094848;font-family: initial;font-size: 16px;"><b>• Quality & Flexibility</b></p>
                                    <p style="color:#094848;font-family: initial;font-size: 16px;line-height: 1px;"><b>• Individualized Service</b></p>
                                    <p style="color:#094848;font-family: initial;font-size: 16px;"><b>• Motivated Professionals</b></p>

                                </div>
                            </div>
                        </div>
                    </div><!-- /.col-md-4 -->
                    <div class="col-md-4 col-sm-6 col-xs-12">
                        <div class="feature-2">
                            <div class="media">
                                <div class="pull-left">
                                    <i class="fa fa-sun-o"></i>
                                    <div class="border"></div>
                                </div>
                                <div class="media-body">
                                    <h4 class="media-heading" style="color: #094848;font-size: 18px;font-family: initial;line-height: 0px;"><b>Why Professionals choose us</b></h4>
                                    <p style="color:#094848;font-family: initial;font-size: 16px;"><b>• Excellent Benefits Package</b></p>
                                    <p style="color:#094848;font-family: initial;font-size: 16px;line-height: 1px;"><b>• Exciting Career Opportunities</b></p>
                                    <p style="color:#094848;font-family: initial;font-size: 16px;"><b>• Competitive Compensation Package</b></p>
                                </div>
                            </div>
                        </div>
                    </div>
                   <div class="col-md-4 col-sm-6 col-xs-12">
                        <div class="feature-2">
                            <div class="media">
                                <div class="pull-left">
                                    <i class="fa fa-flag-checkered"></i>
                                    <div class="border"></div>
                                </div>
                                <div class="media-body">
                                    <h4 class="media-heading" style="color:#094848;font-size: 18px;font-family: initial;line-height: 0px;"><b>Our Principles </b></h4>
                                    <p style="color:#094848;font-family: initial;font-size: 16px;"><b>• People</b></p>
                                    <p style="color:#094848;font-family: initial;font-size: 16px;line-height: 1px;"><b>• Services</b></p>
                                    <p style="color:#094848;font-family: initial;font-size: 16px;"><b>• Costs</b></p>

                                </div>
                            </div>
                        </div>
                    </div>
                <!--    <div class="col-md-4 col-sm-6 col-xs-12">
                        <div class="feature-2">
                            <div class="media">
                                <div class="pull-left">
                                    <i class="fa fa-plug"></i>
                                    <div class="border"></div>
                                </div>
                                <div class="media-body">
                                    <h4 class="media-heading"style="color: black;font-size: 15px;font-family: initial;"><b>Client Services</b></h4>
                                    <p style="color: #082509;font-family: initial;"><b>At eDorpon, we aim to provide you with the most complete progressive, involving and fulfilling SOFTWARE recruitment service available.</b></p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-6 col-xs-12">
                        <div class="feature-2">
                            <div class="media">
                                <div class="pull-left">
                                    <i class="fa fa-joomla"></i>
                                    <div class="border"></div>
                                </div>
                                <div class="media-body">
                                    <h4 class="media-heading"style="color: black;font-size: 15px;font-family: initial;"><b>our Feature</b></h4>
                                    <p style="color: #082509;font-family: initial;"><b>Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu</b></p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-6 col-xs-12">
                        <div class="feature-2">
                            <div class="media">
                                <div class="pull-left">
                                    <i class="fa fa-cube"></i>
                                    <div class="border"></div>
                                </div>
                                <div class="media-body">
                                    <h4 class="media-heading"style="color: black;font-size: 15px;font-family: initial;"><b>upcoming</b></h4>
                                    <p style="color: #082509;font-family: initial;"><b>Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu</b></p>
                                </div>
                            </div>
                        </div>
                    </div>--->
                    
                </div><!-- /.row -->
            
            </div><!-- /.container -->
        </section>
        <!-- End Feature Section -->
    
    
    
    <!-- Start Fun Facts Section -->
    <section class="fun-facts">
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-sm-6 col-md-3">
                      <div class="counter-item">
                        <i class="fa fa-cloud-upload"></i>
                        <div class="timer" id="item1" data-to="991" data-speed="5000"></div>
                        <h5>Files uploaded</h5>                               
                      </div>
                    </div>  
                    <div class="col-xs-12 col-sm-6 col-md-3">
                      <div class="counter-item">
                        <i class="fa fa-check"></i>
                        <div class="timer" id="item2" data-to="7394" data-speed="5000"></div>
                        <h5>Projects completed</h5>                               
                      </div>
                    </div>
                    <div class="col-xs-12 col-sm-6 col-md-3">
                      <div class="counter-item">
                        <i class="fa fa-code"></i>
                        <div class="timer" id="item3" data-to="18745" data-speed="5000"></div>
                        <h5>Lines of code written</h5>                               
                      </div>
                    </div>
                    <div class="col-xs-12 col-sm-6 col-md-3">
                      <div class="counter-item">
                        <i class="fa fa-male"></i>
                        <div class="timer" id="item4" data-to="8423" data-speed="5000"></div>
                        <h5>Happy clients</h5>                               
                      </div>
                    </div>
            </div>
        </div>
    </section>
    <!-- End Fun Facts Section -->



    <!-- Start Team Member Section -->
    



    <!-- Start Pricing Table Section -->
   
    <!-- End Pricing Table Section -->
    
    
    
    <!-- Start Latest News Section -->
    

    
    
    
    <!-- Start Testimonial Section -->
    
    <!-- End Testimonial Section -->
    
    

    <!-- Clients Aside -->
    
    
    
    
    

    
	
 <footer class="style-1">
            <div class="container">
                <div class="row">
                    <div class="col-md-4 col-xs-12">
                        <span class="copyright">2020 &copy; <a >ALL Rights Reserved by eDorpon</a></span>
                    </div>
                    <div class="col-md-4 col-xs-12" style="margin-left: -11px;">
                        <div class="footer-link">
                            <ul class="pull-right" style="margin-top: 1px;">
                                <li><a href="#">Privacy Policy</a><a href="#">    Terms of Use</a>
                                </li>
                                <!--<li><a href="#">Terms of Use</a>
                                </li>--->
                            </ul>
                        </div>
                    </div>
                    <div class="col-md-4 col-xs-12">
                        <div class="footer-social text-center">
                            <ul>
                                <li><a href="https://twitter.com/edorpon"><i class="fa fa-twitter"></i></a></li>
                                <li><a href="https://www.facebook.com/edorponbd/"><i class="fa fa-facebook"></i></a></li>
                                <li><a href="https://www.linkedin.com/company/edorponofficial/"><i class="fa fa-linkedin"></i></a></li>
                                <li><a href="www.edorpon.com"><i class="fa fa-dribbble"></i></a></li>
                                
                            </ul>
                        </div>
                    </div>
                    
                </div>
            </div>
        </footer>
	




    <div id="loader">
        <div class="spinner">
            <div class="dot1"></div>
            <div class="dot2"></div>
        </div>
    </div>

    

    <!-- jQuery Version 2.1.1 -->
    <script src="js/jquery-2.1.1.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="asset/js/bootstrap.min.js"></script>

    <!-- Plugin JavaScript -->
    <script src="js/jquery.easing.1.3.js"></script>
    <script src="js/classie.js"></script>
    <script src="js/count-to.js"></script>
    <script src="js/jquery.appear.js"></script>
    <script src="js/cbpAnimatedHeader.js"></script>
    <script src="js/owl.carousel.min.js"></script>
	<script src="js/jquery.fitvids.js"></script>
	<script src="js/styleswitcher.js"></script>

    <!-- Contact Form JavaScript -->
    <script src="js/jqBootstrapValidation.js"></script>
    <script src="js/contact_me.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="js/script.js"></script>

</body>

</html>
