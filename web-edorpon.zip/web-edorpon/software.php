<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>eDorpon</title>

    <!-- Bootstrap Core CSS -->
    <link href="asset/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Font Awesome CSS -->
    <link href="css/font-awesome.min.css" rel="stylesheet">
    
    
    <!-- Animate CSS -->
    <link href="css/animate.css" rel="stylesheet" >
    
    <!-- Owl-Carousel -->
    <link rel="stylesheet" href="css/owl.carousel.css" >
    <link rel="stylesheet" href="css/owl.theme.css" >
    <link rel="stylesheet" href="css/owl.transitions.css" >

    <!-- Custom CSS -->
    <link href="css/style.css" rel="stylesheet">
    <link href="css/responsive.css" rel="stylesheet">
    
    <!-- Colors CSS -->
    <link rel="stylesheet" type="text/css" href="css/color/green.css">
    
    
    
    <!-- Colors CSS -->
    <link rel="stylesheet" type="text/css" href="css/color/green.css" title="green">
    <link rel="stylesheet" type="text/css" href="css/color/light-red.css" title="light-red">
    <link rel="stylesheet" type="text/css" href="css/color/blue.css" title="blue">
    <link rel="stylesheet" type="text/css" href="css/color/light-blue.css" title="light-blue">
    <link rel="stylesheet" type="text/css" href="css/color/yellow.css" title="yellow">
    <link rel="stylesheet" type="text/css" href="css/color/light-green.css" title="light-green">

    <!-- Custom Fonts -->
    <link href='http://fonts.googleapis.com/css?family=Kaushan+Script' rel='stylesheet' type='text/css'>
    
    
    <!-- Modernizer js -->
    <script src="js/modernizr.custom.js"></script>

    
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>


<body class="index">
    
    
    <!-- Styleswitcher
================================================== -->
        <div class="colors-switcher">
            <a id="show-panel" class="hide-panel"><i class="fa fa-tint"></i></a>        
                <ul class="colors-list">
                    <li><a title="Light Red" onClick="setActiveStyleSheet('light-red'); return false;" class="light-red"></a></li>
                    <li><a title="Blue" class="blue" onClick="setActiveStyleSheet('blue'); return false;"></a></li>
                    <li class="no-margin"><a title="Light Blue" onClick="setActiveStyleSheet('light-blue'); return false;" class="light-blue"></a></li>
                    <li><a title="Green" class="green" onClick="setActiveStyleSheet('green'); return false;"></a></li>
                    
                    <li class="no-margin"><a title="light-green" class="light-green" onClick="setActiveStyleSheet('light-green'); return false;"></a></li>
                    <li><a title="Yellow" class="yellow" onClick="setActiveStyleSheet('yellow'); return false;"></a></li>
                    
                </ul>

        </div>  
<!-- Styleswitcher End
================================================== -->
<nav class="navbar navbar-default navbar-fixed-top" style="background: black;">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header page-scroll">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand page-scroll" href="#page-top"style="font-family: cursive;">eDorpon</a>
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav navbar-right">
                    <li class="hidden">
                        <a href="#page-top"></a>
                    </li>
                    <li>
                        <a class="page-scroll" href="index.php"style="font-family: cursive;">Home</a>
                    </li>
                    <li>
                        <a class="page-scroll" href="service.php"style="font-family: cursive;">Services</a>
                    </li>
                    <li>
                        <a class="page-scroll" href="portfolio.php"style="font-family: cursive;">Portfolio</a>
                    </li>
                    <li>
                        <a class="page-scroll" href="about.php"style="font-family: cursive;">About</a>
                    </li>
                    
                    <li>
                        <a class="page-scroll" href="team.php"style="font-family: cursive;">Team</a>
                    </li>
                    <li>
                        <a class="page-scroll" href="https://edorpon.com/shop/"style="font-family: cursive;">Shop</a>
                    </li>
                    <li>
                        <a class="page-scroll" href="latestnews.php"style="font-family: cursive;">Latest News</a>
                    </li>
                    <li>
                        <a class="page-scroll" href="product.php"style="font-family: cursive;">Product</a>
                    </li>
                    <li>
                        <a class="page-scroll" href="https://edorpon.com/shop/blog"style="font-family: cursive;">Blog</a>
                    </li>
                    <li>
                        <a class="page-scroll" href="contactcareer.php"style="font-family: cursive;">Careers</a>
                    </li>
                    <li>
                        <a class="page-scroll" href="contact1.php"style="font-family: cursive;">Contact</a>
                    </li>
                    
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container-fluid -->
    </nav>


   
       <div class="top_section">
        <img src="images/about-01.jpg" style=" width: 100%; height: 504px; ">
        
        <h1 style="font-family: initial;color: #fff;margin-top: -85px;font-size: 29px;padding: 10px; margin-left: 61px;"></h1>
    </div>




<section id="feature" class="feature-section" style="padding-top: 70px;">
            <div class="container">
                <div class="row">
                    <div class="col-md-3 col-sm-6 col-xs-12">
                        <div class="feature">
                            <i class="fa fa-briefcase"></i>
                            <div class="feature-content">
                                <h4 style="font-size: 20px;font-family: cursive;">S M S</h4>
                                <p>eDorpon provides a best SMS.It is a  multipose school management software which is used for all administration & learning releted activities.It manage student,teachers,employees,course&all process related to running your institute effciently.</p>
                            </div>
                        </div>
                    </div><!-- /.col-md-3 -->
                    <div class="col-md-3 col-sm-6 col-xs-12">
                        <div class="feature">
                            <i class="fa fa-suitcase"></i>
                            <div class="feature-content">
                                
                                <h4 style="font-size: 20px;font-family: cursive;">SMS Features</h4>
                                <p>eDorpon provides a best School Management Software.See some features- Admission & Fees Management, Attendance Management, Account Management,Human Resource Management, Library Management, Examination Management.</p>
                            </div>
                        </div>
                    </div><!-- /.col-md-3 -->
                    <div class="col-md-3 col-sm-6 col-xs-12">
                        <div class="feature">
                            <i class="fa fa-calculator"></i>
                            <div class="feature-content">
                                <h4 style="font-size: 20px;font-family: cursive;">Evaluation Management</h4>
                                <p>Evaluation management is about working through the process of planning and implementing the evaluation. It is about connecting the critical points during the evaluation process, and thus building a bridge between 1)Evaluation; and 2)A strategy and operational work</p>
                            </div>
                        </div>
                    </div><!-- /.col-md-3 -->
                    <div class="col-md-3 col-sm-6 col-xs-12">
                        <div class="feature">
                            <i class="fa fa-bars"></i>
                            <div class="feature-content">
                                <h4 style="font-size: 17px;font-family: cursive;">Financial Management</h4>
                                <p>eDorpon provides Financial Management.It's provides businesses with a full suite of accounting functions to track daily financial operations and generate quarterly and annual financial statements. It provides tools for reporting, analysis, budgeting</p>
                            </div>
                        </div>
                    </div>
                </div><!-- /.row -->
            
            </div><!-- /.container -->
        </section>




<div id="pricing" class="pricing-section">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="col-md-12">
                        <div class="section-title text-center">
                            <h3 style="
    color: #1da246;
    font-size: 32px;font-family: cursive;
">Smart Academic System</h3>
                            <p class="white-text" style = "font-family: cursive;">Find the best School Management Software for your Academy.Feature’s of the SMS</p>
                        </div>
                    </div>
                </div>
            </div>
                    
            <div class="row">
                        
                <div class="pricing">
                        
                        <div class="col-md-12">
                            <div class="pricing-table">
                                <div class="plan-name">
                                    <h3 style = "font-family: cursive;">System Users</h3>
                                </div> <h5>Administrator</h5>
                               <!-- <div class="plan-price">
                                    <div class="price-value">$49<span>.00</span></div>
                                    <div class="interval">per month</div>
                                </div>--->
                                <div class="plan-list">
                                    <ul>
                                        <li>Teacher</li>
                                        <li>Staff/ Accounts</li>
                                        <li> Online Admission System</li>
                                        <li>Parents/ Student (P. D.)</li>
                                         <li>Global Settings & HR Report </li>
                                         <li> Timetable Module</li>
                                         
                                        

                                    </ul>
                                </div>
                                <div class="plan-signup">
                                    <a href="contact1.php" class="btn-system btn-small" >Contact us</a>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-md-12">
                            <div class="pricing-table">
                                <div class="plan-name">
                                    <h3 style = "font-family: cursive;">Student Module</h3>
                                </div>
                                
                                <div class="plan-list">
                                    <ul >
                                        <li>Student Admission System </li>
                                        <li>Current Student List (Active & Inactive)</li>
                                        <li>Current Student Search</li>
                                        <li>Student Switch Process</li>
                                        <li>Fees Collection With SMS Sending Facility</li>
                                       
                                        <li>Archive Student List&Due Report</li>
                                    </ul>
                                </div>
                                <div class="plan-signup">
                                    <a href="contact1.php" class="btn-system btn-small" >Contact us</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="pricing-table">
                                <div class="plan-name">
                                    <h3 style = "font-family: cursive;">Academic Module</h3>
                                </div>
                                
                                <div class="plan-list">
                                    <ul s>
                                        <li>Subject Configuration</li>
                                        <li>Session Configuration </li>
                                        <li>Medium Configuration, (Bangle, English, Arabic)</li>
                                        <li>Section Configuration</li>
                                        <li>Group Configuration&Daily Attendance Summary</li>
                                         <li>Real Time Biometric Attendance</li>
                                    </ul>
                                </div>
                                <div class="plan-signup">
                                    <a href="contact1.php" class="btn-system btn-small">Contact us</a>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-md-12">
                            <div class="pricing-table">
                                <div class="plan-name">
                                    <h3 style = "font-family: cursive;" >Exam Setting </h3>
                                </div>
                                
                                <div class="plan-list">
                                    <ul >
                                        <li>Exam Terms Setting</li>
                                        <li>Working Days Setting</li>
                                        <li>Assign Exams With Class&Exam T</li>
                                        <li> Exam Part Setting (Written, MCQ, Practical)</li>
                                        <li>Assign Exams With Class & Exam Terns</li>
                                         <li>Admission Admit Card Print</li>

                                    </ul>
                                </div>
                                <div class="plan-signup">
                                    <a href="contact1.php" class="btn-system btn-small">Contact us</a>
                                </div>
                            </div>
                        </div>
                    
                        <div class="col-md-12">
                            <div class="pricing-table">
                                <div class="plan-name">
                                    <h3 style = "font-family: cursive;">General Accounts</h3>
                                </div>
                                
                                <div class="plan-list">
                                    <ul >
                                        <li>Accounts Name Create, We can Use Multiple Account </li>
                                        <li>Chartered Account</li>
                                        <li>Income &Expense Voucher</li>
                                        <li>Income & Expense Report</li>
                                        
                                        <li>Clients/ Party </li>
                                        <li>Salary Grade&Payroll & Increment Management</li>
                                    </ul>
                                </div>
                                <div class="plan-signup">
                                    <a href="contact1.php" class="btn-system btn-small">Contact us</a>
                                </div>
                            </div>
                        </div>
                        
                      <div class="col-md-12">
                            <div class="pricing-table">
                                <div class="plan-name">
                                    <h3 style = "font-family: cursive;" >Attendance and Leave Management </h3>
                                </div>
                               
                                <div class="plan-list">
                                    <ul >
                                        <li>Real Time Attendance Using Wi-Fi Device</li>
                                        <li>Leave Type Management </li>
                                        <li>Attendance Report</li>
                                        <li>Leave Approval Management</li>
                                        <li>Out Work Setup </li>
                                        <li>Salary Report</li>
                                    </ul>
                                </div>
                                <div class="plan-signup">
                                    <a href="contact1.php" class="btn-system btn-small" >Contact us</a>
                                </div>
                            </div>
                        </div>
                        
                    </div>
                        
                        
            </div>
        </div>
    </div>
    


 <footer class="style-1">
            <div class="container">
                <div class="row">
                    <div class="col-md-4 col-xs-12">
                        <span class="copyright">2020 &copy; <a >ALL Rights Reserved by eDorpon</a></span>
                    </div>
                    <div class="col-md-4 col-xs-12" style="margin-left: -11px;">
                        <div class="footer-link">
                            <ul class="pull-right" style="margin-top: 1px;">
                                <li><a href="#">Privacy Policy</a><a href="#">    Terms of Use</a>
                                </li>
                                <!--<li><a href="#">Terms of Use</a>
                                </li>--->
                            </ul>
                        </div>
                    </div>
                    <div class="col-md-4 col-xs-12">
                        <div class="footer-social text-center">
                            <ul>
                                <li><a href="https://twitter.com/edorpon"><i class="fa fa-twitter"></i></a></li>
                                <li><a href="https://www.facebook.com/edorponbd/"><i class="fa fa-facebook"></i></a></li>
                                <li><a href="https://www.linkedin.com/company/edorponofficial/"><i class="fa fa-linkedin"></i></a></li>
                                <li><a href="www.edorpon.com"><i class="fa fa-dribbble"></i></a></li>
                                
                            </ul>
                        </div>
                    </div>
                    
                </div>
            </div>
        </footer>
	




    <div id="loader">
        <div class="spinner">
            <div class="dot1"></div>
            <div class="dot2"></div>
        </div>
    </div>

    

    <!-- jQuery Version 2.1.1 -->
    <script src="js/jquery-2.1.1.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="asset/js/bootstrap.min.js"></script>

    <!-- Plugin JavaScript -->
    <script src="js/jquery.easing.1.3.js"></script>
    <script src="js/classie.js"></script>
    <script src="js/count-to.js"></script>
    <script src="js/jquery.appear.js"></script>
    <script src="js/cbpAnimatedHeader.js"></script>
    <script src="js/owl.carousel.min.js"></script>
	<script src="js/jquery.fitvids.js"></script>
	<script src="js/styleswitcher.js"></script>

    <!-- Contact Form JavaScript -->
    <script src="js/jqBootstrapValidation.js"></script>
    <script src="js/contact_me.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="js/script.js"></script>

</body>

</html>
